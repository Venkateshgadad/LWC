import { LightningElement, track } from 'lwc';

export default class Carlist extends LightningElement {
    
   
  @track searchvalue;
    biketitle(event){
    this.searchvalue = event.detail;
   }
   biketitle = "Honda"
   bikedescription = "TATA New Car"
}
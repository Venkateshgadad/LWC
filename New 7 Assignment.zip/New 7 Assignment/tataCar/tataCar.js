import Name from '@salesforce/schema/Account.Name';
import {api, LightningElement } from 'lwc';

export default class tataCar extends LightningElement {
@api nameofcar 
@api description
price = '$50000';
pictureUrl = 'https://cars.tatamotors.com/images/punch/punch-suv-home-mob.png';
searchkey;
handlechange(event){
  this.searchkey = event.target.value;
    const searchEvent = new CustomEvent("getsearchvalue",{
    detail:this.searchkey
});
    this.dispatchEvent(searchEvent);
}
}

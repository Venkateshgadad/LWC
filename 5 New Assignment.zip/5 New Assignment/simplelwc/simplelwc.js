import { LightningElement, track } from 'lwc';

export default class LwcExample extends LightningElement {
    @track name = '';
    @track greeting = '';

    handleNameChange(event) {
        this.name = event.target.value;
        this.greeting = `Welcome on Board, ${this.name}!`;
    }
}

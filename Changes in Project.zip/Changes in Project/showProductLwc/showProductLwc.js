import { LightningElement,api } from 'lwc';
import getListofProducts from '@salesforce/apex/InventoryManagementController.getListofProducts';
const actions = [
    { label: 'Transfer', name: 'Transfer' },
];
const columns = [
    {
        label: 'ProductName', fieldName: 'Name', type: 'text',
    },
    { label: 'Quantity', fieldName: 'Quantity__c', type: 'text' },
    {   label: 'Action',type: 'action',initialWidth:'50px',typeAttributes: { rowActions: actions },
    },
];
export default class ShowProductLWc extends LightningElement {
    @api warehouseId;
    columns = columns;
    data = [];
    error;
    totalNumberOfRows = 100; // stop the infinite load after this threshold count    
    offSetCount = 0;
    loadMoreStatus;
    targetDatatable; // capture the loadmore event to fetch data and stop infinite loading
    totalProdQty = 0;
    selectedProdId;
    showTransferProd = false;
    connectedCallback() {
        this.getRecords();
        console.log('warehouseId--'+this.warehouseId);
    }
    getRecords() {
        getListofProducts({ warehouseID : this.warehouseId})
            .then(result => {
                result = JSON.parse(JSON.stringify(result));
                result.forEach(record => {
                    this.totalProdQty = this.totalProdQty+record.Quantity__c;
                });
                console.log('result::'+result);
                this.data = [...this.data, ...result];
                this.error = undefined;
            })
            .catch(error => {
                this.error = error;
                this.data = undefined;
                console.log('error : ' + JSON.stringify(this.error));
            });
    }
    handleRowAction(event){
        this.selectedProdId = event.detail.row.Id;
        console.log('fetchedIs--'+this.selectedID);
        this.showTransferProd = true;
    }   
}
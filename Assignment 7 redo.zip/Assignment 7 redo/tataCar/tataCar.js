import Name from '@salesforce/schema/Account.Name';
import {api, LightningElement } from 'lwc';

export default class tataCar extends LightningElement {
@api nameofcar 
@api description 
@api Engine = 'Petrol'
price = '$50000';
pictureUrl = 'https://cars.tatamotors.com/images/punch/punch-suv-home-mob.png';
searchkey = 'Nexon';
handlechange(event){
    const searchEvent = new CustomEvent("getsearchvalue",{
    detail:this.searchkey
    
});
    this.dispatchEvent(searchEvent);
    console.log('Name of car'+ this.searchkey);
}

}

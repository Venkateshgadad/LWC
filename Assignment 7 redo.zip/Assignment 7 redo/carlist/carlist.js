import { LightningElement, track } from 'lwc';

export default class Carlist extends LightningElement {
    
  nameofthecar = '';

  @track searchvalue;
    biketitle(event){
    this.searchvalue = event.detail;
   }
   biketitle = "Honda"
   // bikedescription = "TATA New Car"
   bikedescription(payload){
    console.log(payload.detail);
   this.nameofthecar = payload.detail
   }

}
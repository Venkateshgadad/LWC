import { LightningElement,api } from 'lwc';
import getprodDetails from '@salesforce/apex/InventoryManagementController.getprodDetails';
import saveRecords from '@salesforce/apex/InventoryManagementController.saveRecords';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
export default class TransferProductLwc extends LightningElement {
    @api prodId;
    fromWarehouse;
    toWarehouse;
    quantityToBeTransfered;
    prodName;
    prodDetails;
    oldSku={
        'Id' : '',
        'Quantity__c' : ''
    };
    newSku = {
        'Warehouse__c' : '',
        'Quantity__c' : '',
        'Name' : ''
    };
    existingQuantity;
    connectedCallback() {
        this.getRecords();       
    }
    getRecords() {
        getprodDetails({ prodID : this.prodId})
            .then(result => {
                // Returned result if from sobject and can't be extended so objectifying the result to make it extensible
                result = JSON.parse(JSON.stringify(result));
                this.prodDetails = result;
                this.fromWarehouse = this.prodDetails.Warehouse__r.Name;
                this.prodName = this.prodDetails.Name;
                this.existingQuantity = this.prodDetails.Quantity__c;
                this.error = undefined;
            })
            .catch(error => {
                this.error = error;
                this.data = undefined;
                console.log('error : ' + JSON.stringify(this.error));
            });
    }
    lookupRecord(event){
        this.toWarehouse = event.detail.selectedRecord.Id;
    }
    handleChange(event){
        this.quantityToBeTransfered = event.target.value;
    }
    saveRecord(){
        this.oldSku.Quantity__c = this.existingQuantity - this.quantityToBeTransfered ; 
        this.oldSku.Id = this.prodDetails.Id;
        this.newSku.Quantity__c = this.quantityToBeTransfered;
        this.newSku.Name = this.prodName;
        this.newSku.Warehouse__c = this.toWarehouse;
        console.log('oldsku::'+JSON.stringify(this.oldSku));
        console.log('newsku::'+JSON.stringify(this.newSku));
        saveRecords({
            oldSku : this.oldSku,
            newSku : this.newSku
        })
        .then(result => {
                this.showToast('Success','Successfully transfer the product!!','success');
            })
            .catch(error => {
                this.showToast('Error',JSON.stringify(error),'error');
                console.log('error : ' + JSON.stringify(error));
            });
    }
    showToast(title,message,variant) {
    const evt = new ShowToastEvent({
        title: title,
        message: message,
        variant: variant,
        mode: 'dismissable'
    });
    this.dispatchEvent(evt);
}}
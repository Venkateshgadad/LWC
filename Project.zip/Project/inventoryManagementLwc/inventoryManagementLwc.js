import { LightningElement,wire } from 'lwc';
import getListofWareHouse from '@salesforce/apex/InventoryManagementController.getListofWareHouse';
const actions = [
    { label: 'View', name: 'view' },
];
const columns = [
    {
        label: 'Warehouse Name', fieldName: 'linkwarehouse', type: 'url',
        initialWidth:'50px',typeAttributes: {label: { fieldName: 'Name' },target: '_blank'
        }
    },
    { 
        label: 'Location', fieldName: 'Location__c',initialWidth:'50px', type: 'text' },
    {   
        label: 'Action',type: 'action',initialWidth:'50px',typeAttributes: { rowActions: actions },
    },
];
export default class InventoryManagementLwc extends LightningElement {
    columns = columns;
    data = [];
    error;
    totalNumberOfRows = 100; // stop the infinite load after this threshold count    
    offSetCount = 0;
    loadMoreStatus;
    targetDatatable; // capture the loadmore event to fetch data and stop infinite loading

    connectedCallback() {
        this.getRecords();
    }
    getRecords() {
        getListofWareHouse({ offSetCount: this.offSetCount })
            .then(result => {
                result = JSON.parse(JSON.stringify(result));
                result.forEach(record => {
                    record.linkwarehouse = '/' + record.Id;
                });
                this.data = [...this.data, ...result];
                this.error = undefined;
                this.loadMoreStatus = '';
                if (this.targetDatatable && this.data.length >= this.totalNumberOfRows) {
                    this.targetDatatable.enableInfiniteLoading = false;
                    this.loadMoreStatus = 'No more data to load';
                }
                if (this.targetDatatable) this.targetDatatable.isLoading = false;
            })
            .catch(error => {
                this.error = error;
                this.data = undefined;
                console.log('error : ' + JSON.stringify(this.error));
            });
    }
    handleLoadMore(event) {
        event.preventDefault();
        this.offSetCount = this.offSetCount + 20;
        event.target.isLoading = true;
        this.targetDatatable = event.target;
        this.loadMoreStatus = 'Loading';
        this.getRecords();
    }
    handleRowAction(event){
        this.selectedID = event.detail.row.Id;
        console.log('fetchedIs--'+this.selectedID);
        this.showProd = true;
    }
}
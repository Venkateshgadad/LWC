
const student1 = {
	name: 'John',
	marks: [75, 80, 85, 90, 95]
};

const student2 = {
	name: 'Jane',
	marks: [85, 90, 95, 100, 95]
};

const calculateAveragePercentage = (student) => {
	const totalMarks = student.marks.reduce((total, mark) => total + mark);
	const average = totalMarks / student.marks.length;
	return average.toFixed(2);
};

const student1Average = calculateAveragePercentage(student1);
const student2Average = calculateAveragePercentage(student2);

// Compare the average percentages and print the result
if (student1Average > student2Average) {
	console.log(`${student1.name} has a higher average percentage: ${student1Average}%`);
} else if (student2Average > student1Average) {
	console.log(`${student2.name} has a higher average percentage: ${student2Average}%`);
} else {
	console.log(`Both students have the same average percentage: ${student1Average}%`);
}

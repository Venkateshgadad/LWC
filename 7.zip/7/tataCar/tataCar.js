import Name from '@salesforce/schema/Account.Name';
import {api, LightningElement } from 'lwc';

export default class tataCar extends LightningElement {
@api nameofcar 
@api description 
@api engine 
price = '$50000';
pictureUrl = 'https://cars.tatamotors.com/images/punch/punch-suv-home-mob.png';
//searchkey = 'Nexon';
searchengine = 'Petrol'
handlechange(event){
    console.log('data---'+event.target.value);
    if(event.currentTarget.dataset.id==="carname"){
      const searchEvent = new CustomEvent("getsearchvalue",{
        detail: {
          type: "car",
          name:event.target.value
        } 
      });
      this.dispatchEvent(searchEvent);
    }
    else if(event.currentTarget.dataset.id==="engine"){
      const searchEvent = new CustomEvent("getsearchvalue",{
        detail: {
          type: "engine",
          name:event.target.value
        } 
      });
      this.dispatchEvent(searchEvent);  
    }
    
    
}
handleclick(event){
  const searchEvent = new CustomEvent("getvalue",{
  detail:this.searchengine
  
});
  this.dispatchEvent(searchEvent);
  console.log('Car Engine'+ this.searchengine);
}
}
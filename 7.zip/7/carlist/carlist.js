import { LightningElement, track } from 'lwc';

export default class Carlist extends LightningElement {
    
  nameofthecar = '';
  engine = '';
  carName = 'Nexon';
  engineName = 'PetrolEngine';

  /*@track searchvalue;
    biketitle(event){
    this.searchvalue = event.detail;
   }
   biketitle = "Honda"
   // bikedescription = "TATA New Car"
   bikedescription(payload){
      console.log(payload.detail);
      this.nameofthecar = payload.detail
   }
   carengine(payload){
    console.log(payload.detail)
    this.engine = payload.detail
   }*/
   handleEvent(event){
     console.log('in parent--'+event.detail);
     if(event.detail.type === "car"){
       this.nameofthecar = event.detail.name;
     }
     if(event.detail.type === "engine"){
       this.engine = event.detail.name;
     }
     
   }

}
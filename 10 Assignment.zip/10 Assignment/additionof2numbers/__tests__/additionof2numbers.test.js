import { createElement } from 'lwc';
import Additionof2numbers from 'c/additionof2numbers';

describe('c-additionof2-numbers', () => {
    afterEach(() => {
        // The jsdom instance is shared across test cases in a single file so reset the DOM
        while (document.body.firstChild) {
            document.body.removeChild(document.body.firstChild);
        }
    });

    it('adds two numbers', () => {
        // Arrange
        const element = createElement('c-additionof2-numbers', {
            is: Additionof2numbers
        });

        // Act

        element.firstnum1 = 2;
        element.secondnum2 = 3;
        document.body.appendChild(element);

        // Assert
        // const div = element.shadowRoot.querySelector('div');
        const p = element.shadowRoot.querySelector('p');
        expect(p.textContent).toBe('The sum is: 10');
        
    });
});
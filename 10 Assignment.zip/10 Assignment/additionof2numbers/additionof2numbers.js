import { LightningElement, track } from 'lwc';

export default class Additionof2numbers extends LightningElement {
    @track firstnum1 = 4;
    @track secondnum2 = 6;
    @track sum = 0;

    //display(event){
       // this.firstnum1 = event.target.value;
    
  //  }
   // display1(event){
       // this.secondnum2 = event.target.value;
   // }
   connectedCallback(){
        this.sum= this.firstnum1 + this.secondnum2;
    }
    
}
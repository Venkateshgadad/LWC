import { LightningElement, api } from 'lwc';
import NAME_FIELD from '@salesforce/schema/Account.Name';
import ACCOUNTNUMBER_FIELD from '@salesforce/schema/Account.AccountNumber';

export default class EditFieldForAccountObj extends LightningElement {

    nameField = NAME_FIELD;
    accountnumberField= ACCOUNTNUMBER_FIELD;

    @api recordId;
    @api objectApiName;

}